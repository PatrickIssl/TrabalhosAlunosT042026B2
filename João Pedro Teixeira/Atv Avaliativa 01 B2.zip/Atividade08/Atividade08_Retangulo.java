import java.util.Scanner;

class Retangulo {
    double largura;
    double altura;

    double calcularArea() {
        return largura * altura;
    }

    double calcularPerimetro() {
        return 2 * (largura + altura);
    }
}

public class Atividade08_Retangulo {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Retangulo retangulo = new Retangulo();

        System.out.print("Digite a largura: ");
        retangulo.largura = entrada.nextDouble();

        System.out.print("Digite a altura: ");
        retangulo.altura = entrada.nextDouble();

        System.out.printf("Area: %.2f%n", retangulo.calcularArea());
        System.out.printf("Perimetro: %.2f%n", retangulo.calcularPerimetro());
        entrada.close();
    }
}
