import java.util.Scanner;

class Funcionario {
    String nome;
    String cargo;
    double salario;

    void aumentarSalario(double percentual) {
        if (percentual > 0) {
            salario = salario + (salario * percentual / 100);
        } else {
            System.out.println("O percentual deve ser positivo.");
        }
    }
}

public class Atividade07_Funcionario {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Funcionario funcionario = new Funcionario();

        System.out.print("Digite o nome: ");
        funcionario.nome = entrada.nextLine();

        System.out.print("Digite o cargo: ");
        funcionario.cargo = entrada.nextLine();

        System.out.print("Digite o salario: R$ ");
        funcionario.salario = entrada.nextDouble();

        System.out.print("Digite o percentual de aumento: ");
        double percentual = entrada.nextDouble();

        funcionario.aumentarSalario(percentual);

        System.out.println("Nome: " + funcionario.nome);
        System.out.println("Cargo: " + funcionario.cargo);
        System.out.printf("Novo salario: R$ %.2f%n", funcionario.salario);
        entrada.close();
    }
}
