import java.util.Scanner;

class PessoaCadastro {
    String nome;
    int idade;
    String cidade;

    void apresentar() {
        System.out.println("Ola, meu nome e " + nome + " e tenho " + idade + " anos.");
    }

    void fazerAniversario() {
        idade = idade + 1;
    }

    void exibirDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Cidade: " + cidade);
    }
}

public class Atividade10_CadastroPessoas {
    static void cadastrarPessoa(Scanner entrada, PessoaCadastro pessoa, int numero) {
        System.out.println("\nCadastro da pessoa " + numero);

        System.out.print("Nome: ");
        pessoa.nome = entrada.nextLine();

        System.out.print("Idade: ");
        pessoa.idade = Integer.parseInt(entrada.nextLine());

        System.out.print("Cidade: ");
        pessoa.cidade = entrada.nextLine();
    }

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        PessoaCadastro pessoa1 = new PessoaCadastro();
        PessoaCadastro pessoa2 = new PessoaCadastro();
        PessoaCadastro pessoa3 = new PessoaCadastro();

        cadastrarPessoa(entrada, pessoa1, 1);
        cadastrarPessoa(entrada, pessoa2, 2);
        cadastrarPessoa(entrada, pessoa3, 3);

        System.out.println("\n--- Dados das pessoas ---");
        pessoa1.apresentar();
        pessoa1.exibirDados();

        System.out.println();
        pessoa2.apresentar();
        pessoa2.exibirDados();

        System.out.println();
        pessoa3.apresentar();
        pessoa3.exibirDados();

        System.out.println("\nA primeira pessoa fez aniversario!");
        pessoa1.fazerAniversario();

        System.out.println("\n--- Dados atualizados ---");
        pessoa1.exibirDados();
        System.out.println();
        pessoa2.exibirDados();
        System.out.println();
        pessoa3.exibirDados();

        entrada.close();
    }
}
