public class Main {
public static void main(String[] args) {
   Pessoa p = new Pessoa();
   p.nome = "João";
   p.idade = 18;
   p.apresentar();
}
}
class Pessoa {
String nome;
int idade;
void apresentar() {
   System.out.println("Olá, meu nome é " + nome
           + " e tenho " + idade + " anos.");
}
}
