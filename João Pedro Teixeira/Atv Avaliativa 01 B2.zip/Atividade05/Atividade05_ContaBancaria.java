import java.util.Scanner;

class ContaBancaria {
    String titular;
    double saldo;

    void depositar(double valor) {
        if (valor > 0) {
            saldo = saldo + valor;
            System.out.println("Deposito realizado com sucesso.");
        } else {
            System.out.println("O valor do deposito deve ser positivo.");
        }
    }

    void sacar(double valor) {
        if (valor > 0 && valor <= saldo) {
            saldo = saldo - valor;
            System.out.println("Saque realizado com sucesso.");
        } else {
            System.out.println("Saque nao pode ser realizado: saldo insuficiente ou valor invalido.");
        }
    }

    void exibirSaldo() {
        System.out.printf("Saldo atual: R$ %.2f%n", saldo);
    }
}

public class Atividade05_ContaBancaria {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        ContaBancaria conta = new ContaBancaria();

        System.out.print("Digite o nome do titular: ");
        conta.titular = entrada.nextLine();

        System.out.print("Digite o saldo inicial: R$ ");
        conta.saldo = entrada.nextDouble();

        System.out.print("Digite o valor do deposito: R$ ");
        conta.depositar(entrada.nextDouble());

        System.out.print("Digite o valor do saque: R$ ");
        conta.sacar(entrada.nextDouble());

        System.out.println("Titular: " + conta.titular);
        conta.exibirSaldo();
        entrada.close();
    }
}
